<?php

require_once('/home/k/lineage/gooips/kwutils.php');
require_once('dradis.php');

class lightning {

const tsmin = 1561444360; // roughly strtotime('2019-06-26');
const tsmax = 2097988360; // year 2036 AD

public function __construct($txt, $lat, $lon, $deg) {
	$this->latbase = $lat;
	$this->lonbase = $lon;
	$this->radDegLimit = $deg;
	$this->initTextDat = $txt;
}

private function isInDegLimit($lat, $lon) {
	if (	abs($lat - $this->latbase) > $this->radDegLimit
		||	abs($lon - $this->lonbase) > $this->radDegLimit) return false;

	return true;
}

public function get() {  


    $baseArr = explode("\n", $this->initTextDat); unset($this->initTextDat);
    $retArr = [];

    foreach($baseArr as $row) {
	$row = trim($row);
	$test = 
	   strlen(trim($row) === 0)
	|| preg_match('/^\[$/', $row)
	|| preg_match('/^\[(-?\d+\.?\d*)\,(-?\d+\.?\d*)\,\"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.?(\d*)\"\,(\d+)\]\,?\]?$/', $row, $matches)
	|| preg_match('/^\]$/', $row);

	kwas($test, $row . ' = ' . 'dangerous stuff!');

	if (!isset($matches[5])) continue;

	$rarr['lon']   = $matches[1];
	$rarr['lat']   = $matches[2];

	if (!$this->isInDegLimit($rarr['lat'], $rarr['lon'])) continue;

	$rarr['date']  = $matches[3] . ' GMT';
	$rarr['ns']    = $matches[4];
	$rarr['mysti'] = $matches[5]; unset($matches);

	$dira = GML_distance($this->latbase, $this->lonbase, $rarr['lat'], $rarr['lon'] );

	$rarr['dist'] = $dira['dist'];
	$rarr['bear'] = $dira['bear'];
	$rarr['dir']  = $dira['dir']; unset($dira);

	$U            = strtotime($rarr['date']);

	kwas($U > self::tsmin && $U < self::tsmax, 'time outside of limits');

	$rarr['U'   ]  = $U;
	$rarr['r'   ]  = date('r', $U);
	$rarr['Uusf']  = $U + floatval('0.' . $rarr['ns']);
	$rarr['Unss']  = $U . '.' . $rarr['ns']; unset($U);

	$retArr[] = $rarr; unset($rarr);

    } // loop
    return $retArr;
} // func
} // class