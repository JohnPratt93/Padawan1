<?php

require_once('/home/k/lineage/gooips/kwutils.php');
require_once('doLightning.php');

/*  curl http://map.blitzortung.org/GEOjson/strikes_0.json --output lj4.txt
    curl -I http://map.blitzortung.org/GEOjson/strikes_0.json
 */

$txt = file_get_contents('/tmp/lj4.txt');
$lo = new lightning($txt, 34.249685, -84.140483, 5); // Sawnee

var_dump($lo->get());