<?php

require_once('/opt/kwynn/kwutils.php');
require_once('dao.php');
require_once('doLightning.php');

/*  curl http://map.blitzortung.org/GEOjson/strikes_0.json --output lj4.txt
    curl -I http://map.blitzortung.org/GEOjson/strikes_0.json
 */
/* rough limits of ATL radar background:

N: 35.4
E: -80.546
S: 30.335
W: -86.033
 * 
 */

// $txt = file_get_contents('/tmp/lj5.txt');
$dao = new lightning_dao();
$res = $dao->getRaw();
$txt = $res['raw'];
$lo = new lightning($txt, 34.249685, -84.140483, ['n' => 35.4, 'e' => -80.546, 's' => 30.335, 'w' => -86.033]); // Sawnee

var_dump($lo->get());