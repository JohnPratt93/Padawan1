<?php

require_once('/opt/kwynn/kwutils.php');

class lightning_dao extends dao_generic {
    const db = 'lightning';
    function __construct() {
	parent::__construct(self::db);
	$this->rawcoll    = $this->client->selectCollection(self::db, 'raw');
    }
    
    function putRaw($dat) {
	$this->rawcoll->insertOne($dat);
    }
}

$dat['ts'] = time();
$dat['r']  = date('r', $dat['ts']);
$res = '';
$res = file_get_contents('http://map.blitzortung.org/GEOjson/strikes_0.json');

$dat['raw'] = $res;
$dat['len'] = strlen($res);
$dat['v']   = -48.999;

$dao = new lightning_dao();

$dao->putRaw($dat);
