<?php

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once('kwutils.php');

$paths = [
        'topo' => ['path' => '/home/k/Downloads/FFC_Topo_Short.jpg'  , 'op' => 100],
    	'cnty' => ['path' => '/home/k/Downloads/FFC_County_Short.gif', 'op' => 100],
       // 'legd' => ['path' => '/home/k/Downloads/FFC_N0R_Legend_0.gif', 'op' =>  100], // Legend has the timestamp
                'rivr' => ['path' => '/home/k/Downloads/FFC_Rivers_Short.gif', 'op' =>  60],
                'high' => ['path' => '/home/k/Downloads/FFC_Highways_Short.gif', 'op' =>  100],
             	'radr' => ['path' => '/home/k/Downloads/FFC_N0R_0.gif'	     , 'op' =>  80],
                    'city' => ['path' => '/home/k/Downloads/FFC_City_Short.gif', 'op' =>  100],

];

$imgs = [];

foreach($paths as $name => $row) {
    
    $tarr['size'] = getimagesize($row['path']);
    if ($tarr['size']['mime'] === 'image/gif') $tarr['gdr']  = imagecreatefromgif($row['path']);
    else				       $tarr['gdr']  = imagecreatefromjpeg($row['path']);
    
    $tarr['type'] = $name;
    $tarr['op']    = $row['op'];
    
    $imgs[] = $tarr;
}

$x = 2;

// imagecopy ( resource $dst_im , resource $src_im , int $dst_x , int $dst_y , int $src_x , int $src_y , int $src_w , int $src_h ) : bool

for ($i = 0; $i < count($imgs) - 1; $i++)
    imagecopymerge($imgs[0]['gdr'], 
	      $imgs[$i+1]['gdr'],
	      0, 0,
		0, 0,
	      $imgs[$i]['size'][0],
	      $imgs[$i]['size'][1],
	      $imgs[$i + 1]['op']
	    );

imagegif($imgs[0]['gdr'], '/tmp/proc2.gif');


