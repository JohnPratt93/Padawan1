<?php

class radar_dao extends dao_generic {
    const db = 'radar';
    function __construct() {
	parent::__construct(self::db);
	$this->icoll  = $this->client->selectCollection(self::db, 'img');
	$this->pxcoll = $this->client->selectCollection(self::db, 'pixels');
    }
    
    public function put($dat) {	
	$seq = $this->getSeq('radar_img');
	$dat['seq'] = $seq;
	$this->icoll->upsert(['modts' => $dat['modts']], $dat);    
    }
    
    public function putPixel($dat) {
	$this->pxcoll->upsert(['x' => $dat['x'], 'y' => $dat['y'], 'seq' => $dat['seq']], $dat);
    }

    public function getLatest($tsonly = false, $allDates = false) {
	$res = $this->icoll->findOne([], ['sort' => ['exts' => -1]]);
	if      ($tsonly && !$allDates) return $res['exts'];
	else if ($tsonly &&  $allDates) {
	    unset($res['img']);
	    return $res;
	}
	return $res;
    }
    
    public function setPixelsInserted($seq) {
	$this->icoll->upsert(['seq' => $seq], ['status' => 'pixels_inserted']);
    }
    
    public function getStatus($seq) {
	$res = $this->icoll->findOne(['seq' => $seq], ['projection' => ['status' => true]]);
	return $res['status'];
    }
}
