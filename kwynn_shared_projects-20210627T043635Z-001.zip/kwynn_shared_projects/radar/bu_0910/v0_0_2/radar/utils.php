<?php

require_once('get.php');

function getFNfromModTS($ts) {
  
    $dates = date('Ymd_Hi', $ts);
    $fname = radar_get::radid . '_' . $dates . '_' . radar_get::pastUrlDir . '.gif';        
    
 // https://radar.weather.gov/RadarImg/NCR/FFC/FFC_20190630_1302_NCR.gif
    return $fname;
    
}