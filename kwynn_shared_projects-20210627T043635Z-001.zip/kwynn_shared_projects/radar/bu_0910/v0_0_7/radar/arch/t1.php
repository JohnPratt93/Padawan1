<?php

exit(0); // disabling before u/loading *************

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once('kwutils.php');

$radid = 'FFC'; // ATL airport

if (0) {
    $url = 'https://radar.weather.gov/RadarImg/N0R/' . $radid . '_N0R_0.gif';
    $x = 2;


    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_FILETIME, true);
    curl_setopt($curl, CURLOPT_NOBODY, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36');
    $header = curl_exec($curl);
    curl_close($curl);

		    file_put_contents('/tmp/radhead1.txt', $header);
} else $header =    file_get_contents('/tmp/radhead1.txt');

kwas(isset($header[50]) && $header && is_string($header), 'curl / http header invalid on face'); // size of 50 is somewhat arbitrary

preg_match('/^HTTP\/[\d\.]+ (\d+ \w+)/', $header, $matches); kwas(isset($matches[1]), 'regex 1 fail'); kwas($matches[1] === '200 OK', 'http error');

$dateTypes = ['Last-Modified: ' => 'mod', 'Expires: ' => 'ex', 'Date: ' => 'gotat'];

foreach($dateTypes as $type => $short) {
    preg_match('/' . $type  . '([^\n]+)/', $header, $matches); kwas(isset($matches[1]), 'date regex fail');
    $ts = strtotimeRecent($matches[1]);
    $y = 17383;
}
$x = 2;
