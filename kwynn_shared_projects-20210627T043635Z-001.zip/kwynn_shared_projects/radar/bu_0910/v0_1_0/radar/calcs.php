<?php

/*
179 - 469 GA border straight with TN

290px
141.48 miles
0.4879 miles / pixel


179  86 - GA border TN AL
262 403 - Chatt River E point below Columbus
192.35 miles
*/

    $my = 86;
    $mx = 179;
    $ry = 403;
    $rx = 262;

    $dx = $rx - $mx;
    $dy = $my - $ry;
    
    $distp = intval(round(sqrt($dx * $dx + $dy * $dy)));
    
    // echo $distp;
    
    // echo 192.35 / $distp; // 0.586
    
    echo 0.586 / 0.4879;
    
    