<?php

require_once('/opt/kwynn/kwutils.php');

$path = '/tmp/GOES_band_7.jpg';

$info = getimagesize($path);
$img  = imagecreatefromjpeg($path);

$topcnt = 32; // 16 looks great for everything except distinguishing non-rain clouds
kwas(imagetruecolortopalette($img, false, $topcnt), 'to palette failed');

$htt  = '';


if (1) {
    
    $cols = [];
$htt .= '<p>';

$setcnt = 0;
for ($x=0; $x < $info[0]; $x++)
for ($y=0; $y < $info[1]; $y++)
{
    $ci = imagecolorat($img, $x, $y);
    if (!isset($cols[$ci])) $cols[$ci] = 0;
    $cols[$ci]++;
    
    /*
    if (imagecolorat($img, $x, $y) === 13) {
	$htt .= ("($x, $y), ");
	if ($setcnt++ > 40) break 2;
    }*/
    
    
}
$htt .= '</p>';
}

for ($i=0; $i < $topcnt; $i++) {
    $c = imagecolorsforindex($img, $i);
    $r = $c['red'];
    $g = $c['green'];
    $b = $c['blue'];
    $xyz = 2;
    
    $htt .= "<tr><td style='height: 20px; width: 20px; background-color: rgb($r, $g, $b)'></td>";
    $htt .= "<td>$r</td><td>$g</td><td>$b</td><td>" . number_format($cols[$i]) . "</td>";
    $htt .= "</tr>";
}

    $htt .= '</table>';