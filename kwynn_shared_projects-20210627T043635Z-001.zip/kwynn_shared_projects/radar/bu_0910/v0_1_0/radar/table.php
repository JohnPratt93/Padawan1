<?php

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once('kwutils.php');
require_once('dao.php');

$dao = new radar_dao();

$resa = $dao->getToMe();

$x = 23432;