<?php

require_once('/opt/kwynn/kwutils.php');

$path = '/tmp/GOES_band_7.jpg';

$info = getimagesize($path);
$img  = imagecreatefromjpeg($path);

$topcnt = 12;
kwas(imagetruecolortopalette($img, true, $topcnt), 'to palette failed');

$cols = [];

$proc = 0;

for ($x=0; $x < $info[0]; $x++)
for ($y=0; $y < $info[1]; $y++)
{
    
    $rgb = imagecolorat($img, $x, $y);
    if (!isset($cols[$rgb])) $cols[$rgb] = 0;
    $cols[$rgb]++;
    
    if ($proc++ % 200000 === 0) echo number_format($proc) . "\n";

}

// var_dump($cols);

imagejpeg($img, '/tmp/GOES_band_7_p_' . $topcnt . '_dithered.jpg');

foreach($cols as $pi => $cnt) {
    $c = imagecolorsforindex($img, $pi);
    $r = $c['red'];
    $g = $c['green'];
    $b = $c['blue'];
    $xyz = 2;
}