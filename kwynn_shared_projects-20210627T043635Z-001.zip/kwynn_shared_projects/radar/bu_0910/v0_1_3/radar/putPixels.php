<?php

require_once('legend.php');
require_once('getStormDist.php');

function putPixels($path, $shortId, $seq, $modr, $modts) {

$dao = new radar_dao();

if ($dao->getStatus($seq) === 'pixels_inserted') return;

$tome = [];

$info = getimagesize($path);
$img  = imagecreatefromgif($path);

$lego = new radar_colors();

$c24todbza = $lego->getc24todbza();

for ($x=0; $x < $info[0]; $x += 1)
for ($y=0; $y < $info[1]; $y += 1)
{
    
    $rgb = imagecolorat($img, $x, $y);
    $c = imagecolorsforindex($img, $rgb);
    $r = $c['red'];
    $g = $c['green'];
    $b = $c['blue'];

    $c24 = ($r << 16) + ($g << 8) + $b;
    if (!  isset($c24todbza[$c24])) { /* deal with color not found in legend */ continue; }
    $dbz =       $c24todbza[$c24];
    if ($dbz < 7) continue;
    
    $dat1 = ['x' => $x, 'y' => $y, 'dbz' => $dbz, 'seq' => $seq, 'short_id' => $shortId];
    
    $dat2 = getStormDist($x, $y);
    
    $dat = array_merge($dat1, $dat2);
    
    if (!isset($tome[$dbz]['dist']) || $tome[$dbz]['dist'] > $dat2['dist']) 
	$tome[$dbz] = $dat;
    
    
    // $dao->putPixel($dat);
}

asort($tome);

assignColorsToMe($tome, $lego);

$fdat['mod'] = $modr;
$fdat['modts'] = $modts;

$fdat['tome'] = $tome;
$fdat['seq']  = $seq;
$fdat['short'] = $shortId;

$dao->setPixelsInserted($seq);
$dao->putToMe($fdat);
$y = 2323;
}

function assignColorsToMe(&$tome, $lego) {
    foreach($tome as $dbz => $dat) {
	$color = $lego->getColorHuman($dbz);
	$tome[$dbz]['color'] = $color;
    }
}