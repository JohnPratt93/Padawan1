<?php

require_once('/opt/kwynn/kwutils.php');

if (php_uname('n') === 'kp' && time() < strtotime('2019-09-20')) getFCList();

function getFCList() {

$pathBase = '/home/k/tech/sm19/adar_large/forecast1';
$imgBase  = $pathBase . '_files/';

$txt = file_get_contents('/home/k/tech/sm19/adar_large/forecast1.html');
$dom = getDOMO($txt); unset($txt);

$c1 = $dom->getElementById('seven-day-forecast-list');

$imgs = $c1->getElementsByTagName('img');

$xpath  = new DomXpath($dom);

$i = 1;
$xbase = "ul[@id='seven-day-forecast-list']";
do {
    $e = $xpath->query("//$xbase/li[$i]/div[1]/p[1]")->item(0);
    if (!$e) break;
    $arr[$i - 1]['period'] = $e->textContent;
    $img = $xpath->query("//$xbase/li[$i]/div[1]/p[2]/img[1]")->item(0);
    $src = $img->getAttribute('src');
    $ipath = basename($src);
    $arr[$i - 1]['src'] = $ipath;
    $arr[$i - 1]['descr'] = $img = $xpath->query("//$xbase/li[$i]/div[1]/p[3]")->item(0)->textContent;
    $arr[$i - 1]['temp'] = $img = $xpath->query("//$xbase/li[$i]/div[1]/p[4]")->item(0)->textContent;    

} while($i++);

return $arr;

}