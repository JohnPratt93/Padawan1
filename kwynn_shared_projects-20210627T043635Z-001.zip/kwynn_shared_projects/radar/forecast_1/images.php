<?php

// use md5 as key and MongoDB
// also use md5 of image for duplicates

// both I and O in this

// function 