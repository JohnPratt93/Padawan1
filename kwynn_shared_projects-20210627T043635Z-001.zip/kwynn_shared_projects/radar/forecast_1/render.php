<?php
require_once('f1.php');

function getForeHT() {

$arr = getFCList();
$ht = '';
for ($i=0; $i < count($arr); $i++) {
    $src = $arr[$i]['src'];
    $ht .= "<div class='child'>";
    $po  = $arr[$i]['period'];
    $night   = (strpos($po, 'Night') || $po === 'Tonight') && $po !== 'Today';
    $pa   = substr($po, 0, 3);

    $pf = $pa . ($night && $pa !== 'Ton' ? ' Nt.' : '');

    if ($pf === 'Ton' || $pf === 'Tod') $pf = 'Now';

    $ht .= $pf . "<br />";
    $ht .= "<img src='/f1imgs/$src' /><br/>";
    $to  = $arr[$i]['temp'];
    $to  = preg_replace('/[^\d]/', '', $to);
    $class = $night ? 'low' : 'high';
    $ht .= "<span class='$class'>" . $to . '</span>';
    $ht .= "</div>";
}

return $ht;
}