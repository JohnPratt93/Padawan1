<?php

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once(__DIR__ . '/dao.php');
require_once('isKwGoo.php');
require_once(__DIR__ . '/quota.php');

function restrictedGet($dao) {

    if (!isLQOK($dao) || (!isKwGoo() && PHP_SAPI !== 'cli')) return false;
	
    $dat['ts'] = time();
    $dat['r']  = date('r', $dat['ts']);
    $res = '';
    // $res = file_get_contents('http://map.blitzortung.org/GEOjson/strikes_0.json');

    $dat['raw'] = $res;
    $dat['len'] = strlen($res);
    $dat['v']   = -48.999;

    $dao->putRaw($dat);    
    
    return true;
}
