<?php

require_once('dao.php');
require_once('rget.php');

$res = cwa_rget(40000);
$polys = cwa_raw_parse($res);
$x = 2;

function cwa_raw_parse($dbin) {
    if (!$dbin) return false;
    if (!isset($dbin['res'])) return false;
    $raw = $dbin['res'];
    if (	!isset($raw['features']) 
	    ||	!is_array($raw['features'])) return false;
    $feas = $raw['features'];

    unset($dbin, $raw);    
    
    $res = [];
    $i   = 0;
    
    foreach($feas as $f) {
	if (	!isset($f['properties']['hazard'])
	     ||        $f['properties']['hazard'] !== 'CONVECTIVE') continue;
	
	if (!isset($f['geometry']['coordinates'][0])) continue;
	$cos     = $f['geometry']['coordinates'][0]; unset($f);
	if (!is_array($cos)) continue;
	
	$j = 0;
	foreach($cos as $co) {
	    $res[$i][$j]['lat'] = $co[0];
	    $res[$i][$j]['lon'] = $co[1];
	    $j++;
	} unset($cos, $co);
	
	$i++;
    } unset($feas, $i, $j);

    return $res;
    
}


