<?php

require_once('f1.php');
require_once(__DIR__ . '/dao.php');


if (php_uname('n') === 'kp' && time() < strtotime('2019-03-20')) {
    forecast::imgInit();
    
}

class forecast {
    
    const urlBase = 'https://forecast.weather.gov/';
    const fcSfx   = 'MapClick.php?CityName=Gainesville&state=GA&site=FFC&lat=34.2941&lon=-83.835';

    public function __construct() {
	$this->dao = new forecast_dao();
    } 
    
public function imgInit() {
    
    $ls = getFCList();
    foreach($ls as $v) {
	$src = $v['src'];
	$cnt = $this->dao->hasIcon($src);
	if (!$cnt) {
	    $img = $this->iconGet($src);
	    $dat['name'] = $src;
	    $dat['img']  = $img;
	    $this->dao->putIcon($dat);
	}
	$abc = 3;	
    }
}

public function get() {
    return $this->internalGet(self::urlBase . self::fcSfx, true);
}

private function iconGet($src) {
    return $this->internalGet(self::urlBase . $src);
}

private function internalGet($url, $mtime = false) {
    
    if ($mtime) {
	$cres = $this->dao->getCached();
	if ($cres) return $cres['body'];
	if (!isKwGoo() && php_uname('n') !== 'kp') return $this->dao->getLatestFC();
    }
     
    
    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_USERAGENT, kwua());
    if ($mtime) 
    curl_setopt($curl, CURLOPT_HEADER, 1);   
    
    $got = curl_exec($curl);  
    
    if ($mtime) {
	$header_len = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
	$head = substr($got, 0, $header_len);
	$ret = [];
	$ret['body'  ] = substr($got, $header_len);
	
	preg_match('/' . 'Expires: '  . '([^\n]+)/', $head, $matches); kwas(isset($matches[1]), 'date regex fail');
	$ret['exr']  = trim($matches[1]);
	$ret['exts'] = intval(strtotimeRecent($ret['exr']));
	
	curl_close($curl);
	
	$this->dao->putForecast($ret);
	
	return $ret['body'];
    }
    
    curl_close($curl);
    
    return $got;
}

}