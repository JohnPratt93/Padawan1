<?php

require_once(__DIR__ . '/../dao.php');

class forecast_dao extends radar_dao {
    
    public function __construct() {
	parent::__construct();
	$this->icoll = $this->client->selectCollection(self::db, 'icons');
	$this->fcoll = $this->client->selectCollection(self::db, 'forecast');
	$this->exSort = ['sort' => ['exts' => -1]];
    }
    
    public function hasIcon($n) {
	$r1 = $this->icoll->findOne(['name' => $n]);
	if (!$r1) return 0;
	return 1;
    }
    
    public function putIcon($dat) {
	
	$dat['img'] = base64_encode($dat['img']);
	$res = $this->icoll->upsert(['name' => $dat['name']], $dat);
	$id = (string) $res->getUpsertedId();
	return $id;
    }
    
    public function getCached() { return $this->fcoll->findOne(['exts' => ['$gte' => time()]], $this->exSort );    }
    
    public function getLatestFC() { return $this->fcoll->findOne([], $this->exSort);    }

    public function putForecast($dat) { $this->fcoll->insertOne($dat);   }
    public function getIconID($p) { 
	$res = $this->icoll->findOne(['name' => $p], ['projection' => ['_id' => true]]);
	if (!$res) return false;
	return (string)$res['_id'];
    }
    
    public function getIcon($iid) { 
	$res = $this->icoll->findOne(['_id' => new MongoDB\BSON\ObjectId($iid)], ['projection' => ['img' => true]]); 
	return base64_decode($res['img']);
	
    }
}
