<?php

require_once('/opt/kwynn/kwutils.php');

class lightning_dao extends dao_generic {
    const db = 'lightning';
    function __construct() {
	parent::__construct(self::db);
	$this->rawcoll = $this->client->selectCollection(self::db, 'raw');
	$this->p1coll  = $this->client->selectCollection(self::db, 'p1');
    }
    
    function putRaw($dat) { $this->rawcoll->insertOne($dat); }
    
    function getRaw() {
	return $this->rawcoll->findOne([], ['sort' => ['ts' => -1], 'limit' => 1]);
    }
    
    function ago($ago = 3600) {
	$since = time() - $ago;
	return $this->rawcoll->count(['ts' => ['$gt' => $since]]);
    }
    
    function putP1($dat) { $this->p1coll->insertOne($dat); }
    
    function getP1($limit = 1, $since = 12000) { 
	$res = $this->p1coll->find(['atts' => ['$gt' => time() - $since]], ['sort' => ['atts' => -1], 'limit' => $limit])->toArray();
	if ($limit === 1 && isset($res[0])) return $res[0];
	return $res;
    }
    
    function getClosest($ago = 3600 * 3) {
	$since = time() - $ago;	
	$res = $this->p1coll->find(['atts' => ['$gt' => $since]], ['sort' => ['atts' => -1]] )->toArray();
	return $res;
    }
}

if (time() < strtotime('2019-08-27 03:00')) {
    $dao = new lightning_dao();
    $dao->getClosest();
}
