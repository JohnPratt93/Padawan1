<?php

function isLQOK($dao) {
    if (php_uname('n') === 'kp') $limits = [12 =>  1, '0.2' => 1 ,  '0.1' => 1];
    else			 $limits = [24 => 35, 1 => 12 ,  '0.1' => 1];
       
    foreach($limits as $lim => $cnt) {
	$acnt = $dao->ago($lim * 3600);
	if ($acnt >= $cnt) return false;
    }
    
    return true;
}