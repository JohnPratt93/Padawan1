<?php

require_once('/opt/kwynn/kwutils.php');

class lightning_dao extends dao_generic {
    const db = 'lightning';
    function __construct() {
	parent::__construct(self::db);
	$this->rawcoll    = $this->client->selectCollection(self::db, 'raw');
    }
    
    function putRaw($dat) { $this->rawcoll->insertOne($dat); }
    
    function getRaw() {
	return $this->rawcoll->findOne([], ['sort' => ['ts' => -1], 'limit' => 1]);
    }
    
    function ago($ago = 3600) {
	$since = time() - $ago;
	return $this->rawcoll->count(['ts' => ['$gt' => $since]]);
    }
}
