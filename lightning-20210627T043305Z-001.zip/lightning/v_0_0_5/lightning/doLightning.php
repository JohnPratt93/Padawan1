<?php

require_once('/opt/kwynn/kwutils.php');
require_once('dradis.php');

class lightning {

public function __construct($txt, $lat, $lon, $lims = []) {
    $this->latbase = $lat;
    $this->lonbase = $lon;
    $this->lllimits = $lims;
    $this->initTextDat = $txt;
    $this->maxU = 0;
    $this->minU = PHP_INT_MAX;
    $this->minD = 70000; // larger than possible distance on earth in mi or km
}

private function isInDegLimit($lat, $lon) {
    
    $l = $this->lllimits;
    if (!$l) return true;
    
    if (       $lat >= $l['s'] // assumes W hemisphere and N hemi., I think.
	    && $lat <= $l['n']
	    && $lon >= $l['w']
	    && $lon <= $l['e']
	    ) return true;
    
    return false;
    
}

public function get() {  


    $baseArr = explode("\n", $this->initTextDat); unset($this->initTextDat);
    $retArr = [];

    $toti = 0;
    $inbi = 0;
    
    foreach($baseArr as $row) {
	$row = trim($row);
	$test = 
	   strlen(trim($row) === 0)
	|| preg_match('/^\[$/', $row)
	|| preg_match('/^\[(-?\d+\.?\d*)\,(-?\d+\.?\d*)\,\"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.?(\d*)\"/', $row, $matches)
	|| preg_match('/^\]$/', $row);

	kwas($test, $row . ' = ' . 'dangerous stuff!');
	
	if (!isset($matches[4])) continue;
	
	$toti++;

	$rarr['lon']   = $matches[1];
	$rarr['lat']   = $matches[2];

	$rarr['date']  = $matches[3] . ' GMT';	
	$U            = strtotimeRecent($rarr['date']);
	
	if ($U > $this->maxU) $this->maxU = $U;
	if ($U < $this->minU) $this->minU = $U;
		
	if (!$this->isInDegLimit($rarr['lat'], $rarr['lon'])) continue;

	$rarr['latlon'] = $rarr['lat'] . ' ' . $rarr['lon'];
	
	$rarr['ns']    = $matches[4]; unset($matches);

	$dira = GML_distance($this->latbase, $this->lonbase, $rarr['lat'], $rarr['lon'] );

	$d = intval(round($dira['dist']));
	$rarr['dist'] = $d;
	
	if ($d < $this->minD) {
	    $this->minD = $d;
	    $this->minI = $inbi;
	    
	}
	
	$rarr['bear'] = $dira['bear'];
	$rarr['dir']  = $dira['dir']; unset($dira);


	$rarr['U'   ]  = $U;
	$rarr['r'   ]  = date('r', $U);
	$rarr['Uusf']  = $U + floatval('0.' . $rarr['ns']);
	$rarr['Unss']  = $U . '.' . $rarr['ns']; unset($U);

	$retArr['strikes'][$inbi++] = $rarr; unset($rarr);

    } // loop

    kwas(count($baseArr) - $toti <= 4, 'bad wc versus toti');
    
    $retArr['minDate'] = date('r', $this->minU);
    $retArr['maxDate'] = date('r', $this->maxU);
    $retArr['mints'] = $this->minU;
    $retArr['maxts'] = $this->maxU;
    $retArr['inBounds'] = $inbi;
    $retArr['tot'] = $toti;
    $retArr['closestI'] = $this->minI;
    
    return $retArr;
} // func
} // class