<?php

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once('dao.php');
require_once('isKwGoo.php');

$dao = new lightning_dao();
$cnt = $dao->ago();
$x = 2;

function regGet() {
    
    if (!isKwGoo()) return;
    
    $limits = [86400 => 35, 3600 => 10, 60 => 3, 5 => 1];
    

    
}

function get() {
    $dat['ts'] = time();
    $dat['r']  = date('r', $dat['ts']);
    $res = '';
    $res = file_get_contents('http://map.blitzortung.org/GEOjson/strikes_0.json');

    $dat['raw'] = $res;
    $dat['len'] = strlen($res);
    $dat['v']   = -48.999;

    $dao = new lightning_dao();

    $dao->putRaw($dat);    
}
