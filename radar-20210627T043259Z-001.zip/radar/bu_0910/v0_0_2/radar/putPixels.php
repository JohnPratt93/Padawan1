<?php

require_once('legend.php');

function putPixels($path, $shortId, $seq) {

$dao = new radar_dao();

if ($dao->getStatus($seq) === 'pixels_inserted') return;

$info = getimagesize($path);
$img  = imagecreatefromgif($path);

$lego = new radar_colors();

$c24todbza = $lego->getc24todbza();

for ($x=0; $x < $info[0]; $x += 1)
for ($y=0; $y < $info[1]; $y += 1)
{
    
    $rgb = imagecolorat($img, $x, $y);
    $c = imagecolorsforindex($img, $rgb);
    $r = $c['red'];
    $g = $c['green'];
    $b = $c['blue'];

    $c24 = ($r << 16) + ($g << 8) + $b;
    if (!  isset($c24todbza[$c24])) { /* deal with color not found in legend */ continue; }
    $dbz =       $c24todbza[$c24];
    if ($dbz < 7) continue;
    
    $dao->putPixel(['x' => $x, 'y' => $x, 'dbz' => $dbz, 'seq' => $seq, 'short_id' => $shortId]);
}

$dao->setPixelsInserted($seq);
$y = 2323;
}