<?php

// v0.0.3 2019/08/15 4:24pm
// v0.0.2 2019/07/01 10:22pm EDT
// packaging for apprentice - We'll call this v0.0.2
// 6/30 4:30pm - dateTZ
// 6/29 4:44pm - added IP loose regex
// Kwynn Buess, kwynn.com, moving to /opt/kwynn for the first time: 2019/06/28 6:25pm EDT

function my_error_handler($errno, $errstr, $errfile, $errline) {
    echo "ERROR: ";
    echo pathinfo($errfile, PATHINFO_FILENAME) . '.';
    echo pathinfo($errfile, PATHINFO_EXTENSION);
    echo ' LINE: ' . $errline . ' - ' . $errstr ;
    exit(37);
}

set_error_handler('my_error_handler');


set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/composer');
require_once('vendor/autoload.php');

class kwmoncli extends MongoDB\Client {
    public function __construct() {
	parent::__construct('mongodb://127.0.0.1/', [], ['typeMap' => ['array' => 'array','document' => 'array', 'root' => 'array']]);
    }

    public function selectCollection     ($db, $coll, array $optionsINGORED_see_below = []) {
	// Kwynn 2019/08/15 4:24pm adding my own options while ignoring $options param, but a param is needed for subclass compatibility
	return new kwcoll($this->getManager(), $db, $coll, ['typeMap' => ['array' => 'array','document' => 'array', 'root' => 'array']]); 
    }
}

class kwcoll extends MongoDB\Collection {
    public function upsert($q, $set) {
	return $this->updateOne($q, ['$set' => $set], ['upsert' => true]);
    }
}

class dao_generic {
    
    protected $dbname;
    protected $client;
    
    private   $seqcoll;
    private   $seqName;
    
    public function __construct($dbname) {
	$this->dbname = $dbname;
	$this->client = new kwmoncli();
    }
    

    
    protected function getSeq($name) {
	$this->seqName = $name;
	$this->seqcoll = $this->client->selectCollection($this->dbname, 'seqs');	
	$this->setSeq();
	$ret = $this->seqcoll->findOneAndUpdate([ '_id' => $this->seqName ], [ '$inc' => [ 'seq' => 1 ]]);
        return $ret['seq'];
    }
    
    private function setSeq() {
	$res = $this->seqcoll->findOne(['_id' => $this->seqName ]);
	if ($res) return;
	$this->seqcoll->insertOne(['_id' => $this->seqName, 'seq' => 1, 'initR' => date('r')]);
    }
}

function kwas($data = false, $msg = 'no message sent to kwas()') {
    if (!isset($data) || !$data) throw new Exception($msg);
}



function strtotimeRecent($strorts, $alreadyTS = false) {
    static $min = 1561500882; // June 25, 2019 during the day
    static $max = false;
    
    if (!$alreadyTS) $ts = strtotime($strorts); 
    else	     $ts = $strorts;
    
    kwas($ts && $ts >= $min, 'bad string to timestamp pass 1 = ' . $strorts);
    
    if (!$max) $max = time() + 87000; kwas($ts < $max, 'bad string to timestamp pass 2 = ' . $strorts);

    return $ts;
}

define('KWYNN_USERAGENT', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36');

define('KWYNN_IP_ETH_REGEX_LOOSE', '/[\dA-Fa-f:\.]{7,39}/');

function dateTZ($format, $ts, $tz) {
    
    $dateO = new DateTime();
    $dateO->setTimestamp($ts);
    $dateO->setTimezone(new DateTimeZone($tz));
    return $dateO->format($format);

}
