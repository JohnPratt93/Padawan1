<?php

// first upload to apprentices, call it v0.0.2 - 2019/07/03 10:38pm EDT

set_include_path(get_include_path() . PATH_SEPARATOR . '/opt/kwynn');
require_once('kwutils.php');
require_once('regGet.php');
require_once('utils.php');
require_once('putPixels.php');

function mymain() {
$geto = new regulated_get();
$dat = $geto->rget();
$path = $dat['tmp'];
$img = base64_decode($dat['img']);
file_put_contents($path, $img);
putPixels($path, $dat['short_id'], $dat['seq'], $dat['mod'], $dat['modts']);
}

mymain();

//me: x 351 y 175



