<?php
$ht = <<<THEHT1
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>colors</title>
	
	<style>
	    td { text-align: right; }
	</style>
</head>
<body>
    <table>
THEHT1;

require_once('getAllColorsGOES.php');

$ht .= $htt;
$ht .= '</body></html>';

file_put_contents('/tmp/ht.html', $ht);


