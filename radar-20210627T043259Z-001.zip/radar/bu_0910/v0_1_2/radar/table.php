<?php

require_once('/opt/kwynn/kwutils.php');
require_once('dao.php');
require_once('getAndDo.php');
// require_once('utils.php');

getRadar();

$dao  = new radar_dao(); 
$tome = $dao->getToMe();  unset($dao);

$lego = new radar_colors();
$tomei = $tome[0]; // just the last one, for now
$tome  = $tomei['tome']; // just the array, for now
$modts = $tomei['modts']; unset($tomei);

$ht  = '';
$ht .= '<table style="font-family: monospace">' . "\n";
// $ht .= '<tr><th>&nbsp;</th><th>mi</th><th>&nbsp;</th></tr>';

$time = time();
$tdiff = $time - $modts;
$limit = 20 * 60; 
$recent = $tdiff < $limit;

foreach($tome as $dbz => $dat) {

    if (!$recent) {
	$ht .= '<tr><td>no recent data</td></tr>' . "\n";
	break;
    }
    
    $rgb = $lego->getCSSRGB($dbz);
    $ht .= "<tr><td class='color' style='background-color: $rgb'>&nbsp;</td>";
    $d = $dat['dist'];
    $ht .= "<td class='dist' style='" . decorateDist($dbz, $d) . "'>$d</td>";
    $ht .= "<td>" . degToLab($dat['dir']) . "</td>";
    // $ht .= "<td>$dat[dir]</td>";
    $ht .= "</tr>\n";
}

$ht .= '</table>' . "\n";

$ht .= '<p>';

if ($tdiff < 70000) $ht .= 'as of ' . date('g:i A', $modts);
else $ht .= 'very old data';

$ht .= '</p>' . "\n";

$ht .= '<p>disk use: ' . round(diskUse(), 1) . '%</p>' . "\n";


unset($tome, $rgb, $lego, $dbz, $dat);

function decorateDist($db, $di) {
   if ($di >= 100) return 'color: gray';
   if ($db > 15 && $di < 30) return 'font-size: 120%; font-weight: bold';
   return '';
}

function diskUse() {
    $r = disk_free_space('/') / disk_total_space('/');
    $p = 100 - $r * 100;
    return $p;
}