<?php

class radar_get {
    const urlBase1 = 'https://radar.weather.gov/RadarImg/';
    const urlDir = 'NCR';
    const radid   = 'FFC'; // ATL airport
    const urlBase2     = self::urlBase1 . self::urlDir. '/';
    const urlCurr      = self::urlBase2 . self::radid . '_' . self::urlDir . '_0.gif';
    const pastUrlBase = self::urlBase2 . self::radid . '/';
   
    protected static function get($honly = false) {
	
	$head = self::getInternal(true);

	$dateTypes = ['Last-Modified: ' => 'mod', 'Expires: ' => 'ex', 'Date: ' => 'gotat'];

	foreach($dateTypes as $type => $short) {
	    preg_match('/' . $type  . '([^\n]+)/', $head, $matches); kwas(isset($matches[1]), 'date regex fail');
	    $ts = strtotimeRecent($matches[1]);
	    $dates[$short . ''] = $matches[1];
	    $dates[$short . 'ts'] = $ts;
	}
	
	$dates['file']  = self::getFNfromModTS($dates['modts']);
	$dates['url'] = self::pastUrlBase . $dates['file'];
	
	if ($honly) return $dates;
	
	$ret = $dates;
		
	$img = self::getInternal(false);
	$ret['size'] = strlen($img);
	$ret['img'] = base64_encode($img);
	$ret['radid'] = self::radid;
	$ret['short_id'] = dateTZ('Hi', $ret['modts'], 'America/New_York');
	
	return $ret;
	
    }
    
    protected static function getFNfromModTS($ts) {
	$ts = strtotimeRecent($ts, true);
	$dates = dateTZ('Ymd_Hi', $ts, 'GMT');
	$fname = radar_get::radid . '_' . $dates . '_' . radar_get::urlDir . '.gif';        
	return $fname;
    }
    
    
    private static function getInternal($honly) {

	$curl = curl_init();
	
	if ($honly) {
	    curl_setopt($curl, CURLOPT_NOBODY, true);
	    curl_setopt($curl, CURLOPT_HEADER, true);
	}
	
	$url = self::urlCurr;

	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_FILETIME, true);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_USERAGENT, kwua());
	$got = curl_exec($curl);  
	if ($honly) self::check($got);
	curl_close($curl);
	
	return $got;
    }
    
    private static function check($tock) {
	kwas(isset($tock[3]) && $tock && is_string($tock), 'curl / http header invalid on face'); // size of 3 is somewhat arbitrary
	preg_match('/^HTTP\/[\d\.]+ (\d+ \w+)/', $tock, $matches); kwas(isset($matches[1]), 'regex 1 fail'); kwas($matches[1] === '200 OK', 'http error');	
    }
}