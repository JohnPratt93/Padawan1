<?php

require_once('get.php');
require_once('dao.php');

class regulated_get extends radar_get {
    const tmpf = '/tmp/radar_temp.txt';
    const testAddEx = 0;
    
    function __construct() {
	$this->dao = new radar_dao();
    }
    
    public function rget() {

	$donew = time() > $this->dao->getLatest(true) + self::testAddEx  ? true : false;
	
	if ($donew) {
	    $dat = radar_get::get(!$donew);
	    $dat['seq'] = $this->dao->put($dat); // Kwynn 2019/08/10 12:00pm
	    $dat = array_merge($dat, $this->getURLs());
	    $dat['seq'] = $this->dao->put($dat);
	    return $dat;
	} else return $this->dao->getLatest();
	
    }
    public function getURLs() {
	$res = $this->dao->getLatest(true, true);
	$fn = self::getFNfromModTS($res['modts']);
	$urlPast = self::pastUrlBase . $fn;
	return ['curr' => self::urlCurr, 'past' => $urlPast, 'tmp' => '/tmp/' . $fn];
    }
}