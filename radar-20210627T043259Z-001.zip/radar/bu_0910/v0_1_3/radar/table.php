<?php

require_once('/opt/kwynn/kwutils.php');
require_once('dao.php');
require_once('getAndDo.php');
// require_once('utils.php');

getRadar();

$dao  = new radar_dao(); 
$tomeall = $dao->getToMe();  unset($dao);

$lego = new radar_colors();

$ht  = '';
$ht .= '<table style="font-family: monospace">' . "\n";
// $ht .= '<tr><th>&nbsp;</th><th>mi</th><th>&nbsp;</th></tr>';

/*
$time = time();
$tdiff = $time - $modts;
$limit = 20 * 60; 
$recent = $tdiff < $limit;
*/

foreach($tomeall as $tomerow) {
    $tome  = $tomerow['tome'];   
    foreach($tome as $dbz => $ignore) $alldbz[$dbz] = true;
}

krsort($alldbz);

$rowi=0;
foreach($alldbz as $dbz => $ignore) {
    $dbzflat[] = $dbz;
    for($i=0; $i < count($tomeall); $i++) $alldat[$dbz][$i] = $tomeall[$i];
}

krsort($alldat);

$lastcoli = count($tomeall) - 1;


for($rowi=0; $rowi < count($alldbz); $rowi++) {

    $ht .= '<tr>';

    $dbz = $dbzflat[$rowi];

for($coli=0; $coli <= $lastcoli; $coli++) {

    $modts  = $alldat[$dbz][$coli]['modts'];    
   
    if ($rowi + $coli === 0) $ht .= '<td></td>';

    $rgb = $lego->getCSSRGB($dbz);
    if ($coli === 0 && $rowi > 0) $ht .= "<td class='color' style='background-color: $rgb'>&nbsp;</td>";
    if ($rowi === 0) $ht .= '<td colspan="2">' . date('g:iA', $modts) . '</td>';
    else if (isset($alldat[$dbz][$coli]['tome'][$dbz])) { 
	$tome =    $alldat[$dbz][$coli]['tome'][$dbz];
	
	$d = $tome['dist'];
	$ht .= "<td class='dist' style='" . decorateDist($dbz, $d) . "'>$d</td>";
	$ht .= "<td>" . degToLab($tome['dir']) . "</td>";
    } else $ht .= '<td colspan="2"></td>';
    
    if ($coli === $lastcoli) $ht .= '</tr>';
 }
}

$ht .= '</table>' . "\n";

/*
$ht .= '<p>';

if ($tdiff < 70000) $ht .= 'as of ' . date('g:i A', $modts);
else $ht .= 'very old data';

$ht .= '</p>' . "\n";
*/
$ht .= '<p>disk use: ' . round(diskUse(), 1) . '%</p>' . "\n";


unset($tome, $rgb, $lego, $dbz, $dat);

function decorateDist($db, $di) {
   if ($di >= 100) return 'color: gray';
   if ($db > 15 && $di < 30) return 'font-size: 120%; font-weight: bold';
   return '';
}

function diskUse() {
    $r = disk_free_space('/') / disk_total_space('/');
    $p = 100 - $r * 100;
    return $p;
}