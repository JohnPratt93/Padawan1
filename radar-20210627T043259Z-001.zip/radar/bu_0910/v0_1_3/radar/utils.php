<?php

require_once('get.php');

function getFNfromModTS($ts) {
  
    $dates = date('Ymd_Hi', $ts);
    $fname = radar_get::radid . '_' . $dates . '_' . radar_get::pastUrlDir . '.gif';        
    
 // https://radar.weather.gov/RadarImg/NCR/FFC/FFC_20190630_1302_NCR.gif
    return $fname;
    
}

function degToLab($deg) {

  $label = array ("N","NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S","SSW","SW", "WSW", "W", "WNW", "NW", "NNW");
  $dir = $label[ fmod((($deg + 11) / 22.5),16) ];
  return($dir);
}