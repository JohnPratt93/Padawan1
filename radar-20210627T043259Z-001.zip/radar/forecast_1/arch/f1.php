<?php

require_once('/opt/kwynn/kwutils.php');

if (php_uname('n') === 'kp' && time() < strtotime('2019-09-20')) getImgList();

function getImgList() {

$pathBase = '/home/k/tech/sm19/adar_large/forecast1';
$imgBase  = $pathBase . '_files/';

$txt = file_get_contents('/home/k/tech/sm19/adar_large/forecast1.html');
$dom = getDOMO($txt); unset($txt);

$c1 = $dom->getElementById('seven-day-forecast-list');

$imgs = $c1->getElementsByTagName('img');

$xpath  = new DomXpath($dom);
// $t1 = $xpath->query("//packet/proto[@name='geninfo']/field[@name='num' and @show='$frin[frame]']")->item(0)->parentNode->parentNode;
$t1 = $xpath->query('//ul[@id="seven-day-forecast-list"]/li[1]/div[1]/p[1]')->item(0);

echo $t1->textContent;

$ia = [];
foreach($imgs as $img) {
    $src = $img->getAttribute('src');
    $ipath = /*$imgBase .*/ basename($src);
    // echo $ipath . "\n";
    $ia[] = $ipath;
}

return $ia;

}