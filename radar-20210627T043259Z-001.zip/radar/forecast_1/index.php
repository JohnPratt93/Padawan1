<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>forecast</title>

<style>
    body { margin: 0; font-family: "Helvetica Neue", Helvetica,Arial,sans-serif; }

#parent {
  display: flex;
  flex-flow: row wrap;
  height: 90vh;
  align-content: flex-start;
  align-items: flex-start;
  width: 100%;
}

 .child { 
     margin-right: 0.5ex;
     text-align: center;
     border: solid;
     border-width: 2px;
     padding: 1px;
 }
 
 .high {  color: #ef3725;  }
 .low  {  color: #15a3e0;  }


</style>

</head>
<body>
    <div id='parent'>
<?php
    require_once('render.php');
    echo getForeHT();
?>
    </div>
</body>
</html>