<?php

require_once('/opt/kwynn/kwutils.php');

$txt = file_get_contents('/tmp/l2.txt');
$ain = json_decode($txt);

// curl http://map.blitzortung.org/GEOjson/ne_10m_time_zones.geojson 
// curl http://map.blitzortung.org/GEOjson/getjson.php

for($i=0; $i < count($ain->features); $i++) 
    if ($ain->features[$i]->properties->tz_name1st === 'America/New_York') {
	doit($ain->features[$i]->geometry);

    }


// doit($ain);

function doit($oin, $lv = 0) {
    foreach($oin as $key => $val) {
	if (!is_object($val) && !is_array($val)) continue;
	if (is_array($val) && count($val) === 2) {
	    $lat = floatval($val[1]);
	    $lon = floatval($val[0]);
	    
	    // if (abs($lat - 37) < 0.5 && abs($lon + -79.9) < 0.5) 
		echo $lat . ' ' . $lon . "\n";
	}
	/* if ($key === 'properties') { 
	    $val = (array)$val;
	    if (isset($val['time_zone']) 
		    &&$val['time_zone'] === 'UTC-05:00'
		    &&$val['tz_name1st'] === 'America/New_York') 
	    var_dump($val);
	    // exit(0);
	} */
	doit($val, $lv + 1);
    }
}


