<?php

require_once('/opt/kwynn/kwutils.php');
require_once('dao.php');
require_once('doLightning.php');
require_once(__DIR__ . '/get.php');

function getLHT() {

$lo = new lightning(34.249685, -84.140483, ['n' => 35.4, 'e' => -80.546, 's' => 30.335, 'w' => -86.033]); unset($txt);

$dao = new lightning_dao();

$res = $dao->getP1(8);


$ht = '';
if (!$res) return $ht;

for ($i=1; $i <= 2; $i++)
{
$ht .= '<tr>';

$ht .= '<td></td>';

if ($i === 1) {
    $ht .= '<th style="font-size: 250%; font-weight: bold; color: orange; vertical-align: top; ';
    $ht .= 'max-height: 0.7em; margin-bottom: -10px; padding-bottom: -1em; border: 0" ';
    $ht .= 'rowspan = "2">&#x26A1;</th>';
}
// else	      $ht .= '<td></td>';


foreach ($res as $col) {
    if ($i === 1) {
	$at = date('g:iA', $col['atts']);
	$ht .= "<th colspan='2'>$at</th>";
    }
    else {
	$c = $col['closest'];

	foreach (['dist', 'dir'] as $type) {
	    
	    if ($type === 'dist') $ta = 'right';
	    else $ta = 'left';
	    
	    $ht .= "<td style='text-align: $ta'>";
	    if (!$c  && $type === 'dist') $ht .= '&Oslash;';
	    else if ($c) $ht .= "$c[$type]";
	    $ht .= '</td>';
	}
    }
}
$ht .= '</tr>';

}


return $ht;
/*

$r = $lo->get(); unset($lo);
$c = $r['closest'];

if ($c) $cll = $c['dist'] . ' miles ' . $c['dir'] . " on $c[r] " .  ' = closest strike ';
else    $cll = 'none within ~200 miles';

$lmin = round(($r['maxts'] - $r['mints']) / 60);

$ht = <<<KWLHT
	<div>
	<h2><label>lightning data</label></h2>
	<p>$cll</p>
	<p>data captured $r[atr]</p>
	<p>worldwide: $r[tot] strikes in $lmin minutes from $r[minDate] to $r[maxDate]</p>
	</div>
KWLHT;

return $ht;
 * 
 */
}