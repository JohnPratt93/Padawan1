<?php

require_once('/opt/kwynn/kwutils.php');

class dao_cwa extends dao_generic {
    const db = 'convective';
    
    function __construct() {
	parent::__construct(self::db);
	$this->ccoll =  $this->client->selectCollection(self::db, 'raw');
    }
    
    function put($url, $datin) {
	$dat['url'] = $url;
	$ts = time();
	$dat['ts'] = $ts;
	$dat['r']  = date('r', $ts);
	$dat['res'] = $datin;
	$this->ccoll->insertOne($dat);
	
    }
    
    function get($since = 7200, $limit = 1) {
	$res = $this->ccoll->find(['ts' => ['$gt' => time() - $since]], ['sort' => ['ts' => -1], 'limit' => $limit])->toArray();	
	if ($limit === 1) return $res[0];
    }
}


