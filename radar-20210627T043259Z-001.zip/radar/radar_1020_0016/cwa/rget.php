<?php

function cwa_rget($since) {
    
    $dao = new dao_cwa();
    $res = $dao->get($since);
    
    if ($res) return $res;

    $url = 'https://www.aviationweather.gov/cgi-bin/json/SigmetJSON.php?type=all&bbox=-86.033,30.335,-80.546,35.4';
    $json = file_get_contents($url);
    $arr = json_decode($json, true);
    $dao = new dao_cwa();
    $dao->put($url, $arr);
    
    return $dao->get();
}



