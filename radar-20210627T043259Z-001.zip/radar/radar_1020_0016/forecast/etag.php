<?php

$fmtime = 200000; // just something - need to set this
$md5 = '393939'; // same

$gmt = new DateTimeZone('Etc/GMT+0');
$serverDTimeO = new DateTime("now", $gmt);
$serverDTimeO->setTimestamp($fmtime);
$times = $serverDTimeO->format("D, d M Y H:i:s") . " GMT";

header('Last-Modified: ' . $times);
header('ETag: ' . '"' . $md5 . '"');

if ( 1 &&
    (isset($_SERVER['HTTP_IF_MODIFIED_SINCE'])
	&& $_SERVER['HTTP_IF_MODIFIED_SINCE'] === $times)
	||
	(isset($_SERVER['HTTP_IF_NONE_MATCH']) &&
	
	    trim($_SERVER['HTTP_IF_NONE_MATCH']) === $md5
		)
	) { 
    http_response_code(304);
    exit(0);
    }