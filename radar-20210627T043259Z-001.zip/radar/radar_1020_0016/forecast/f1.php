<?php

require_once('/opt/kwynn/kwutils.php');
require_once(__DIR__ . '/get.php');

if (php_uname('n') === 'kp' && time() < strtotime('2019-03-20')) getFCList();

function getFCList() {

$fo = new forecast();
$txt = $fo->get();
$dom = getDOMO($txt); unset($txt);

$c1 = $dom->getElementById('seven-day-forecast-list');

$imgs = $c1->getElementsByTagName('img');

$xpath  = new DomXpath($dom);

$i = 1;
$xbase = "ul[@id='seven-day-forecast-list']";
do {
    $e = $xpath->query("//$xbase/li[$i]/div[1]/p[1]")->item(0);
    if (!$e) break;
    $arr[$i - 1]['period'] = $e->textContent;
    $img = $xpath->query("//$xbase/li[$i]/div[1]/p[2]/img[1]")->item(0);
    $src = $img->getAttribute('src');
    $arr[$i - 1]['rawsrc'] = $src;
    
    $iid = $fo->getIconID($src);
    if (!$iid) $iid = $this->getIconId();
    
    $arr[$i - 1]['srcid'] = $iid;
    
    $arr[$i - 1]['descr'] = $img = $xpath->query("//$xbase/li[$i]/div[1]/p[3]")->item(0)->textContent;
    $arr[$i - 1]['temp'] = $img = $xpath->query("//$xbase/li[$i]/div[1]/p[4]")->item(0)->textContent;    

} while($i++);

$i = 10;
$xbase = "div[@id='detailed-forecast']";
do {
    $descr = $xpath->query("//$xbase/div[2]/div[$i]/div[2]")->item(0)->textContent;
    if (!$descr) break;
    $per = $xpath->query("//$xbase/div[2]/div[$i]/div[1]")->item(0)->textContent;

    $arr[$i - 1]['descr'] = $descr;
    $arr[$i - 1]['period'] = $per;
    
} while($i++ && $i < 15);

$atr = $xpath->query("//div[@id='about_forecast']/div[2]/div[2]")->item(0)->textContent;

return ['days' => $arr, 'atr' => $atr];

}