<?php

echo('Hello world!');

$ignoreMe = 0; // just a line for the debugger to attach to.  You need some sort of active line / command.

// The above is a line for the debugger to attach to.  You need some sort of active line / command.
