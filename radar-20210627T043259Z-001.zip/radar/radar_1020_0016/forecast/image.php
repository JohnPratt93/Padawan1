<?php
// see ETag and such in new file

require_once('dao.php');

kwTSHeaders();

$iid = $_REQUEST['fciid'];

$dao = new forecast_dao();

$img = $dao->getIcon($iid);

header('Content-Type'	        , 'image/png');
// header('Expires'		        , '0');
// header('Cache-Control'		, 'must-revalidate, post-check=0, pre-check=0');
header('Pragma'			, 'public');
header('Content-Length'		,  strlen($img));
ob_clean();
flush();

echo $img;

exit(0);

