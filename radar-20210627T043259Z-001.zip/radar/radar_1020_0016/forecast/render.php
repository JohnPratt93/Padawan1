<?php
require_once('f1.php');


if (php_uname('n') === 'kp' && time() < strtotime('2019-09-20') && PHP_SAPI === 'cli') {
    getForeHT();
}

function getForeHT() {

$arr2 = getFCList();
$arr = $arr2['days'];
$atr = $arr2['atr'];

kwTSHeaders(strtotime($atr));

$ht = '';
for ($i=0; $i < count($arr); $i++) {
    $src = $arr[$i]['srcid'];
    $ht .= "<div class='child'>";
    $po  = $arr[$i]['period'];
    $night   = (strpos($po, 'Night') || $po === 'Tonight') && $po !== 'Today';
    $pa   = substr($po, 0, 3);

    $pf = $pa . ($night && $pa !== 'Ton' ? ' Nt.' : '');

    if ($pf === 'Ton' || $pf === 'Tod') $pf = 'Now';

    if (php_uname('n') === 'kp') $urlBase = 'http://radar/';
    else			 $urlBase = 'https://kwynn.com/t/9/08/radar/';
    
    $ht .= $pf . "<br />";
    $ht .= "<img src='$urlBase" . "forecast/image.php?fciid=$src' /><br/>";
    $to  = $arr[$i]['temp'];
    $to  = preg_replace('/[^\d]/', '', $to);
    $class = $night ? 'low' : 'high';
    $ht .= "<span class='$class'>" . $to . '</span>';
    $ht .= "</div>";
}

$ht .= "<div class='child' style='border: none'>forecast updated: $atr";
$ht .= "<br /><a href='https://forecast.weather.gov/MapClick.php?CityName=Gainesville&state=GA&site=FFC&lat=34.2941&lon=-83.835'>NWS source</a></div>" . "\n";

return $ht;
}