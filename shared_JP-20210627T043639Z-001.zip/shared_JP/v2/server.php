<?php
if (isset($_REQUEST['value'])) 
    echo  $_REQUEST['value'];
